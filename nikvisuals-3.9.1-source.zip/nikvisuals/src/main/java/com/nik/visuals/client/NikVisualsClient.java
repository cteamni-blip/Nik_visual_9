package com.nik.visuals.client;

import com.nik.visuals.client.config.ModConfig;
import com.nik.visuals.client.gui.ConfigScreen;
import com.nik.visuals.client.gui.LayoutEditScreen;
import com.nik.visuals.client.pulse.PulseManager;
import com.nik.visuals.client.render.AmbienceRenderer;
import com.nik.visuals.client.render.ArmorHudRenderer;
import com.nik.visuals.client.render.BlockOutlineRenderer;
import com.nik.visuals.client.render.ColorFilterRenderer;
import com.nik.visuals.client.render.CooldownHudRenderer;
import com.nik.visuals.client.render.ComboHudRenderer;
import com.nik.visuals.client.render.HitMarkerRenderer;
import com.nik.visuals.client.render.TotemIndicatorRenderer;
import com.nik.visuals.client.render.LowHpVignetteRenderer;
import com.nik.visuals.client.render.FullbrightHandler;
import com.nik.visuals.client.render.HungerHudRenderer;
import com.nik.visuals.client.render.InventoryHudRenderer;
import com.nik.visuals.client.render.OptimizeHandler;
import com.nik.visuals.client.render.PotionsRenderer;
import com.nik.visuals.client.render.TargetHUD;
import com.nik.visuals.client.render.TrajectoryRenderer;
import com.nik.visuals.client.render.WatermarkRenderer;
import com.nik.visuals.client.render.WeatherHandler;
import com.nik.visuals.client.slot.HealCooldowns;
import com.nik.visuals.client.slot.SlotTimerRenderer;
import com.nik.visuals.client.swap.TalismanSwapHandler;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Environment(EnvType.CLIENT)
public class NikVisualsClient implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("nikvisuals");

    @Override
    public void onInitializeClient() {
        LOGGER.info("Nik Visuals 3.2");
        ModConfig.load();

        TargetHUD targetHUD = new TargetHUD();
        PotionsRenderer potionsRenderer = new PotionsRenderer();
        WatermarkRenderer watermarkRenderer = new WatermarkRenderer();
        InventoryHudRenderer inventoryHud = new InventoryHudRenderer();
        TrajectoryRenderer traj = new TrajectoryRenderer();
        BlockOutlineRenderer blockOutline = new BlockOutlineRenderer();
        FullbrightHandler fullbright = new FullbrightHandler();
        OptimizeHandler optimize = new OptimizeHandler();
        WeatherHandler weather = new WeatherHandler();
        AmbienceRenderer ambience = new AmbienceRenderer();
        ColorFilterRenderer colorFilter = new ColorFilterRenderer();
        HungerHudRenderer hunger = new HungerHudRenderer();
        ArmorHudRenderer armorHud = new ArmorHudRenderer();
        CooldownHudRenderer cooldownHud = new CooldownHudRenderer();
        ComboHudRenderer comboHud = new ComboHudRenderer();
        HitMarkerRenderer hitMarker = new HitMarkerRenderer();
        TotemIndicatorRenderer totemInd = new TotemIndicatorRenderer();
        LowHpVignetteRenderer lowHp = new LowHpVignetteRenderer();
        PulseManager pulse = new PulseManager();
        TalismanSwapHandler talismanSwap = new TalismanSwapHandler();
        SlotTimerRenderer slot = new SlotTimerRenderer();

        KeyBinding menuKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.nikvisuals.open_config", GLFW.GLFW_KEY_RIGHT_SHIFT, KeyBinding.Category.MISC));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) {
                if (client.currentScreen instanceof ConfigScreen) {
                    client.setScreen(null);
                } else if (client.currentScreen == null) {
                    client.setScreen(new ConfigScreen(null, targetHUD, potionsRenderer, watermarkRenderer, inventoryHud));
                }
            }
            boolean swapDown = false;
            try {
                long win = client.getWindow().getHandle();
                swapDown = GLFW.glfwGetKey(win, ModConfig.talismanKey) == GLFW.GLFW_PRESS;
            } catch (Throwable ignored) {}
            talismanSwap.tick(client, swapDown);
            targetHUD.tick(client);
            comboHud.tick(client);
            hitMarker.tick(client);
            totemInd.tick(client);
            lowHp.tick(client);
            pulse.tick(client);
            slot.tick(client);
            fullbright.tick(client);
            optimize.tick(client);
            weather.tick(client);
            HealCooldowns.tick();
        });

        ClientPlayConnectionEvents.DISCONNECT.register((h, c) -> HealCooldowns.clear());

        HudRenderCallback.EVENT.register((ctx, tc) -> {
            float pt = tc.getTickProgress(true);
            if (MinecraftClient.getInstance().currentScreen instanceof LayoutEditScreen) {
                return;
            }
            try {
                colorFilter.render(ctx, pt);
                ambience.render(ctx, pt);
                drawCoords(ctx);
                if (ModConfig.targetHud) targetHUD.render(ctx, pt);
                if (ModConfig.potions) potionsRenderer.render(ctx, pt);
                if (ModConfig.watermark) watermarkRenderer.render(ctx, pt);
                if (ModConfig.inventoryHud) inventoryHud.render(ctx, pt);
                hunger.render(ctx, pt);
                armorHud.render(ctx, pt);
                cooldownHud.render(ctx, pt);
                pulse.renderHud(ctx, pt);
                talismanSwap.render(ctx, pt);
                lowHp.render(ctx, pt);
                hitMarker.render(ctx, pt);
                comboHud.render(ctx, pt);
                totemInd.render(ctx, pt);
            } catch (Throwable t) {
                LOGGER.debug("HUD render error", t);
            }
        });

        WorldRenderEvents.BEFORE_TRANSLUCENT.register(context -> {
            try {
                float pt = MinecraftClient.getInstance().getRenderTickCounter().getTickProgress(true);
                MatrixStack pose = context.matrices();
                VertexConsumerProvider buffers = context.consumers();
                if (pose != null && buffers != null) {
                    blockOutline.render(pose, buffers, pt);
                    traj.renderWorld(pose, buffers, pt);
                }
            } catch (Throwable t) {
                LOGGER.debug("World render error", t);
            }
        });
    }

    private void drawCoords(DrawContext g) {
        if (!ModConfig.showCoords) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.crosshairTarget == null || mc.crosshairTarget.getType() != HitResult.Type.BLOCK) return;
        BlockPos pos = ((BlockHitResult) mc.crosshairTarget).getBlockPos();
        g.drawCenteredTextWithShadow(mc.textRenderer,
                pos.getX() + " " + pos.getY() + " " + pos.getZ(),
                mc.getWindow().getScaledWidth() / 2,
                mc.getWindow().getScaledHeight() / 2 + 14,
                0xFFE8F5EC);
    }
}
