package com.nik.visuals.client.render;

import com.nik.visuals.client.config.ModConfig;
import com.nik.visuals.client.theme.Anim;
import com.nik.visuals.client.theme.Style;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

@Environment(EnvType.CLIENT)
public class PotionsRenderer {
    private float appear;
    private int lastX, lastY, lastW, lastH;
    public static final int LINE = 18;

    public int getLastX() { return lastX; }
    public int getLastY() { return lastY; }
    public int getLastW() { return lastW; }
    public int getLastH() { return lastH; }

    public void render(DrawContext g, float pt) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null) return;

        List<StatusEffectInstance> list = new ArrayList<>(p.getStatusEffects());
        boolean show = (ModConfig.potions && !list.isEmpty()) || ModConfig.layoutEdit;
        appear = Anim.approach(appear, show ? 1f : 0f, 0.14f);
        if (appear < 0.02f) return;

        float a = Anim.easeOutCubic(appear);
        float scale = Math.max(0.6f, Math.min(1.6f, ModConfig.potionsScale));
        int x = (int) (ModConfig.potionsX * mc.getWindow().getScaledWidth());
        int y = (int) (ModConfig.potionsY * mc.getWindow().getScaledHeight());

        if (list.isEmpty() && ModConfig.layoutEdit) {
            lastX = x; lastY = y; lastW = (int) (110 * scale); lastH = (int) (32 * scale);
            g.getMatrices().pushMatrix();
            g.getMatrices().translate(x, y);
            g.getMatrices().scale(scale, scale);
            GuiDraw.glassPanel(g, 0, 0, 110, 32, 10, Style.alpha(Style.PANEL, a), Style.alpha(Style.ACCENT_GLOW, a));
            g.drawText(mc.textRenderer, "Potions", 14, 12, Style.alpha(Style.TEXT_DIM, a), false);
            g.getMatrices().popMatrix();
            return;
        }
        if (list.isEmpty()) return;

        list.sort((a1, b1) -> {
            boolean ah = a1.getEffectType().value().getCategory() == StatusEffectCategory.HARMFUL;
            boolean bh = b1.getEffectType().value().getCategory() == StatusEffectCategory.HARMFUL;
            if (ah != bh) return ah ? 1 : -1;
            return Integer.compare(b1.getDuration(), a1.getDuration());
        });

        int maxW = 90;
        for (StatusEffectInstance e : list) {
            maxW = Math.max(maxW, 26 + mc.textRenderer.getWidth(label(e)) + 10);
        }
        int h = 6 + list.size() * LINE;
        lastX = x; lastY = y; lastW = (int) (maxW * scale); lastH = (int) (h * scale);

        g.getMatrices().pushMatrix();
        g.getMatrices().translate(x + (1f - a) * -6f, y);
        g.getMatrices().scale(scale, scale);

        GuiDraw.glassPanel(g, 0, 0, maxW, h, 10, Style.alpha(Style.PANEL, a), Style.alpha(Style.ACCENT_GLOW, a));

        int row = 0;
        for (StatusEffectInstance e : list) {
            int ry = 4 + row * LINE;
            boolean harm = e.getEffectType().value().getCategory() == StatusEffectCategory.HARMFUL;

            // aligned 16x16 icon box
            int ix = 5, iy = ry;
            GuiDraw.fillRounded(g, ix, iy, 16, 16, 4, Style.alpha(Style.GLASS, a));

            boolean drew = false;
            try {
                Identifier id = e.getEffectType().getKey().map(k -> k.getValue()).orElse(null);
                if (id != null) {
                    Identifier tex = Identifier.of(id.getNamespace(), "textures/mob_effect/" + id.getPath() + ".png");
                    // pipeline, id, x, y, u, v, width, height, textureWidth, textureHeight
                    g.drawTexture(RenderPipelines.GUI_TEXTURED, tex, ix, iy, 0f, 0f, 16, 16, 16, 16);
                    drew = true;
                }
            } catch (Throwable ignored) {}
            if (!drew) {
                int col = harm ? Style.DANGER : Style.OK;
                GuiDraw.fillSoftCircle(g, ix + 8, iy + 8, 5, Style.alpha(col, a));
            }

            int textC = harm ? Style.alpha(Style.DANGER, a) : Style.alpha(Style.OK, a);
            g.drawText(mc.textRenderer, label(e), 24, ry + 4, textC, false);
            row++;
        }
        g.getMatrices().popMatrix();
    }

    private String label(StatusEffectInstance e) {
        String name = e.getEffectType().value().getName().getString();
        if (name.length() > 12) name = name.substring(0, 11) + "…";
        int amp = e.getAmplifier();
        String a = amp > 0 ? " " + (amp + 1) : "";
        int sec = Math.max(0, e.getDuration() / 20);
        return name + a + " " + String.format("%d:%02d", sec / 60, sec % 60);
    }
}
