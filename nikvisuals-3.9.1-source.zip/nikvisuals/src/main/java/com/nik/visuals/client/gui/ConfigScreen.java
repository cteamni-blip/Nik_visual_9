package com.nik.visuals.client.gui;

import com.nik.visuals.client.config.ModConfig;
import com.nik.visuals.client.render.GuiDraw;
import com.nik.visuals.client.render.InventoryHudRenderer;
import com.nik.visuals.client.render.PotionsRenderer;
import com.nik.visuals.client.render.TargetHUD;
import com.nik.visuals.client.render.WatermarkRenderer;
import com.nik.visuals.client.theme.Anim;
import com.nik.visuals.client.theme.Style;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * Futuristic black-green menu (reference layout):
 * left sidebar | center content cards | right empty panel (no image / no profiles)
 */
@Environment(EnvType.CLIENT)
public class ConfigScreen extends Screen {
    private final Screen parent;
    private final TargetHUD targetHUD;
    private final PotionsRenderer potionsRenderer;
    private final WatermarkRenderer watermarkRenderer;
    private final InventoryHudRenderer inventoryHud;

    private enum Nav { HOME, VISUALS, INTERFACE, RENDER, HUD, SETTINGS }
    private Nav nav = Nav.HOME;

    private final List<Row> rows = new ArrayList<>();
    private final float[] knob = new float[64];
    private float openA;
    private String search = "";
    private boolean searchFocus;
    private int scroll;
    private float contentFade = 1f;
    private Nav lastNav = Nav.HOME;

    private int px, py, pw, ph;
    private int sideW = 100;
    private int rightW = 0; // no right panel

    public ConfigScreen(Screen parent, TargetHUD th, PotionsRenderer pr, WatermarkRenderer wm, InventoryHudRenderer inv) {
        super(Text.literal("Nik Visuals"));
        this.parent = parent;
        this.targetHUD = th;
        this.potionsRenderer = pr;
        this.watermarkRenderer = wm;
        this.inventoryHud = inv;
        rebuild();
        for (int i = 0; i < rows.size() && i < knob.length; i++) {
            knob[i] = rows.get(i).get.get() ? 1f : 0f;
        }
    }

    private void rebuild() {
        rows.clear();
        // VISUALS
        add(Nav.VISUALS, "Траектория", "Показывает путь брошенных предметов", () -> ModConfig.trajectory, v -> ModConfig.trajectory = v);
        add(Nav.VISUALS, "Обводка блоков", "Контур блока под прицелом", () -> ModConfig.blockOutline, v -> ModConfig.blockOutline = v);
        add(Nav.VISUALS, "Пульс урона", "Вспышка при ударе", () -> ModConfig.damagePulse, v -> ModConfig.damagePulse = v);
        add(Nav.VISUALS, "Пульс низкого ХП", "Пульсация при малом здоровье", () -> ModConfig.lowHealthPulse, v -> ModConfig.lowHealthPulse = v);
        add(Nav.VISUALS, "Ambience", "Мягкий оверлей атмосферы", () -> ModConfig.ambience, v -> ModConfig.ambience = v);
        add(Nav.VISUALS, "Координаты блока", "XYZ блока под прицелом", () -> ModConfig.showCoords, v -> ModConfig.showCoords = v);
        // INTERFACE
        add(Nav.INTERFACE, "Без эффектов", "Убирает огонь/тряску/тьму на экране", () -> ModConfig.clearEffects, v -> ModConfig.clearEffects = v);
        add(Nav.INTERFACE, "Fullbright", "Постоянный яркий свет", () -> ModConfig.fullbright, v -> ModConfig.fullbright = v);
        add(Nav.INTERFACE, "Оптимизация PvP", "Снижает лишнюю нагрузку", () -> ModConfig.optimizePvp, v -> ModConfig.optimizePvp = v);
        add(Nav.INTERFACE, "Звуки UI", "Тихие клики в меню", () -> ModConfig.uiSounds, v -> ModConfig.uiSounds = v);
        // RENDER
        add(Nav.RENDER, "Погода: выкл/ясно/дождь/гром", "Клиентский оверрайд погоды", () -> ModConfig.weatherMode > 0, v -> ModConfig.weatherMode = v ? 1 : 0);
        // HUD
        add(Nav.HUD, "Target HUD", "Карточка цели", () -> ModConfig.targetHud, v -> ModConfig.targetHud = v);
        add(Nav.HUD, "Частицы на цели", "CRIT частицы на цели", () -> ModConfig.targetParticles, v -> ModConfig.targetParticles = v);
        add(Nav.HUD, "Зелья", "Список эффектов", () -> ModConfig.potions, v -> ModConfig.potions = v);
        add(Nav.HUD, "Ватермарка", "FPS / пинг / название", () -> ModConfig.watermark, v -> ModConfig.watermark = v);
        add(Nav.HUD, "Инвентарь на экране", "Слоты инвентаря", () -> ModConfig.inventoryHud, v -> ModConfig.inventoryHud = v);
        add(Nav.HUD, "HUD кулдаунов", "Иконка + имя + секунды", () -> ModConfig.cooldownHud, v -> ModConfig.cooldownHud = v);
        add(Nav.HUD, "Броня у хотбара", "Прочность брони", () -> ModConfig.armorHud, v -> ModConfig.armorHud = v);
        add(Nav.HUD, "Сытость", "AppleSkin-стиль", () -> ModConfig.saturationHud, v -> ModConfig.saturationHud = v);
        add(Nav.HUD, "Таймер слотов", "КД на хотбаре", () -> ModConfig.slotTimer, v -> ModConfig.slotTimer = v);
        add(Nav.HUD, "Дистанция цели", "Метры до цели", () -> ModConfig.showDistance, v -> ModConfig.showDistance = v);
        add(Nav.HUD, "Комбо ударов", "Счётчик серии ударов", () -> ModConfig.comboHud, v -> ModConfig.comboHud = v);
        add(Nav.HUD, "Хит-маркер", "Крестик при ударе", () -> ModConfig.hitMarker, v -> ModConfig.hitMarker = v);
        add(Nav.HUD, "Индикатор тотема", "Сколько тотемов в инвентаре", () -> ModConfig.totemIndicator, v -> ModConfig.totemIndicator = v);
        add(Nav.HUD, "Виньетка низкого ХП", "Красные края экрана", () -> ModConfig.lowHpVignette, v -> ModConfig.lowHpVignette = v);
        // SETTINGS
        add(Nav.SETTINGS, "Свап талисманов", "Кольцо выбора (Left Alt)", () -> ModConfig.talismanSwap, v -> ModConfig.talismanSwap = v);
        add(Nav.SETTINGS, "Предупреждение брони", "Мигание при низкой прочности", () -> ModConfig.armorWarn, v -> ModConfig.armorWarn = v);
    }

    private void add(Nav n, String title, String desc, Supplier<Boolean> get, Consumer<Boolean> set) {
        rows.add(new Row(n, title, desc, get, set));
    }

    @Override
    protected void init() {
        openA = 0f;
        ModConfig.colorFilter = false;
        float s = Math.max(0.85f, Math.min(1.15f, ModConfig.menuScale));
        pw = (int) (400 * s);
        ph = (int) (230 * s);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
    }

    @Override
    public void render(DrawContext g, int mx, int my, float delta) {
        openA = Anim.approach(openA, 1f, 0.14f);
        float a = Anim.easeOutCubic(openA);

        // dim world
        g.fill(0, 0, width, height, Style.solidAlpha(0x000000, (int) (160 * a)));

        // main panel
        GuiDraw.fillRounded(g, px, py, pw, ph, 8, Style.alpha(Style.PANEL, a));
        // thin border
        g.fill(px, py, px + pw, py + 1, Style.alpha(Style.ACCENT, a * 0.5f));
        g.fill(px, py + ph - 1, px + pw, py + ph, Style.alpha(Style.ACCENT, a * 0.35f));

        drawSidebar(g, mx, my, a);
        drawHeader(g, a);
        drawContent(g, mx, my, a);
        drawRightPanel(g, a);

        super.render(g, mx, my, delta);
    }

    private void drawHeader(DrawContext g, float a) {
        int x = px + sideW + 16;
        int y = py + 14;
        g.drawText(textRenderer, "Nik Visuals", x, y, Style.alpha(Style.TEXT, a), false);
        g.drawText(textRenderer, "v3.9", x + 78, y, Style.alpha(Style.TEXT_DIM, a), false);

        // search
        int sx = x;
        int sy = py + 42;
        int sw = pw - sideW - rightW - 36;
        GuiDraw.fillRounded(g, sx, sy, sw, 18, 8, Style.alpha(0xFF0A0A0A, a));
        g.fill(sx + 4, sy + 16, sx + sw - 4, sy + 17, Style.alpha(Style.ACCENT, a * 0.35f));
        String shown = search.isEmpty() && !searchFocus ? "Поиск..." : search + (searchFocus && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
        g.drawText(textRenderer, shown, sx + 8, sy + 5, Style.alpha(search.isEmpty() && !searchFocus ? Style.TEXT_DIM : Style.TEXT, a), false);
    }

    private void drawSidebar(DrawContext g, int mx, int my, float a) {
        int x = px + 8;
        int y = py + 12;
        g.drawText(textRenderer, "§aNV", x + 8, y, Style.alpha(Style.ACCENT, a), false);
        g.drawText(textRenderer, "v3.9", x + 28, y + 2, Style.alpha(Style.TEXT_DIM, a), false);

        String[] labels = {"Главная", "Визуалы", "Интерфейс", "Рендер", "HUD", "Настройки"};
        Nav[] ids = {Nav.HOME, Nav.VISUALS, Nav.INTERFACE, Nav.RENDER, Nav.HUD, Nav.SETTINGS};
        for (int i = 0; i < labels.length; i++) {
            int by = py + 48 + i * 28;
            boolean on = nav == ids[i];
            boolean hov = mx >= x && mx <= x + sideW - 16 && my >= by && my <= by + 22;
            if (on) {
                GuiDraw.fillRounded(g, x, by, sideW - 16, 20, 4, Style.alpha(Style.ACCENT, a * 0.28f));
            } else if (hov) {
                GuiDraw.fillRounded(g, x, by, sideW - 16, 22, 8, Style.alpha(Style.ROW_HOV, a));
            }
            g.drawText(textRenderer, labels[i], x + 12, by + 7, Style.alpha(on ? Style.TEXT : Style.TEXT_DIM, a), false);
        }

        g.drawText(textRenderer, "1.21.11", x + 6, py + ph - 14, Style.alpha(Style.TEXT_DIM, a * 0.7f), false);
    }

    private void drawRightPanel(DrawContext g, float a) {
        // right panel removed — cleaner layout
    }

    private void drawContent(DrawContext g, int mx, int my, float a) {
        if (lastNav != nav) { contentFade = 0f; lastNav = nav; }
        contentFade = Anim.approach(contentFade, 1f, 0.2f);
        a = a * Anim.easeOutCubic(contentFade);
        int x = px + sideW + 12;
        int y = py + 68;
        int cw = pw - sideW - rightW - 28;

        if (nav == Nav.HOME) {
            g.drawText(textRenderer, "§fДобро пожаловать!", x, y, Style.alpha(Style.TEXT, a), false);
            g.drawText(textRenderer, "Настрой визуалы под себя.", x, y + 12, Style.alpha(Style.TEXT_DIM, a), false);

            String[] cards = {"Визуалы", "Интерфейс", "HUD", "Рендер", "Настройки"};
            Nav[] jump = {Nav.VISUALS, Nav.INTERFACE, Nav.HUD, Nav.RENDER, Nav.SETTINGS};
            for (int i = 0; i < cards.length; i++) {
                int cx = x + (i % 3) * (cw / 3 + 4);
                int cy = y + 36 + (i / 3) * 70;
                int cw2 = cw / 3 - 8;
                GuiDraw.fillRounded(g, cx, cy, cw2, 48, 6, Style.alpha(0xFF121212, a));
                boolean hov = mx >= cx && mx <= cx + cw2 && my >= cy && my <= cy + 60;
                if (hov) g.fill(cx, cy, cx + 2, cy + 60, Style.alpha(Style.ACCENT, a));
                g.drawText(textRenderer, "§a" + cards[i], cx + 12, cy + 16, Style.alpha(Style.TEXT, a), false);
                g.drawText(textRenderer, "открыть", cx + 12, cy + 28, Style.alpha(Style.TEXT_DIM, a), false);
            }

            // move HUD button
            int bx = x;
            int by = py + ph - 36;
            GuiDraw.fillRounded(g, bx, by, 120, 18, 8, Style.alpha(Style.ACCENT, a * 0.45f));
            g.drawCenteredTextWithShadow(textRenderer, "Переместить HUD", bx + 60, by + 5, Style.alpha(Style.TEXT, a));
            return;
        }

        // section title
        String title = switch (nav) {
            case VISUALS -> "Визуалы";
            case INTERFACE -> "Интерфейс";
            case RENDER -> "Рендер";
            case HUD -> "HUD";
            case SETTINGS -> "Настройки";
            default -> "";
        };
        g.drawText(textRenderer, "§a" + title, x, y - 2, Style.alpha(Style.TEXT, a), false);

        // card background
        GuiDraw.fillRounded(g, x - 2, y + 12, cw + 4, ph - 90, 6, Style.alpha(0xFF101010, a));

        String q = search.toLowerCase(Locale.ROOT);
        int rowY = y + 22 - scroll;
        int idx = 0;
        int drawn = 0;
        for (Row r : rows) {
            if (r.nav != nav) { idx++; continue; }
            if (!q.isEmpty() && !r.title.toLowerCase(Locale.ROOT).contains(q)
                    && !r.desc.toLowerCase(Locale.ROOT).contains(q)) {
                idx++;
                continue;
            }
            if (rowY > y + 14 && rowY < py + ph - 50) {
                boolean hov = mx >= x && mx <= x + cw && my >= rowY && my <= rowY + 28;
                if (hov) GuiDraw.fillRounded(g, x, rowY, cw, 28, 8, Style.alpha(Style.ROW_HOV, a));
                g.drawText(textRenderer, r.title, x + 10, rowY + 4, Style.alpha(Style.TEXT, a), false);
                g.drawText(textRenderer, r.desc, x + 10, rowY + 15, Style.alpha(Style.TEXT_DIM, a * 0.9f), false);

                float k = idx < knob.length ? knob[idx] : (r.get.get() ? 1f : 0f);
                k = Anim.approach(k, r.get.get() ? 1f : 0f, 0.25f);
                if (idx < knob.length) knob[idx] = k;
                int tw = 34, th = 18;
                int tx = x + cw - 14 - tw;
                int ty = rowY + 6;
                GuiDraw.toggle(g, tx, ty, tw, th, k,
                        Style.alpha(Style.ACCENT, a),
                        Style.alpha(Style.TRACK_OFF, a),
                        Style.alpha(Style.KNOB, a));
                drawn++;
            }
            rowY += 30;
            idx++;
        }

        if (drawn == 0) {
            g.drawText(textRenderer, "Ничего не найдено", x + 12, y + 40, Style.alpha(Style.TEXT_DIM, a), false);
        }
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x();
        double my = click.y();
        int button = 0;

        // sidebar
        int x = px + 8;
        Nav[] ids = {Nav.HOME, Nav.VISUALS, Nav.INTERFACE, Nav.RENDER, Nav.HUD, Nav.SETTINGS};
        for (int i = 0; i < ids.length; i++) {
            int by = py + 48 + i * 28;
            if (mx >= x && mx <= x + sideW - 16 && my >= by && my <= by + 22) {
                nav = ids[i];
                scroll = 0;
                contentFade = 0f;
                clickUi();
                return true;
            }
        }

        // search
        int sx = px + sideW + 16;
        int sy = py + 42;
        int sw = pw - sideW - rightW - 36;
        searchFocus = mx >= sx && mx <= sx + sw && my >= sy && my <= sy + 18;

        // home cards
        if (nav == Nav.HOME) {
            int cx0 = px + sideW + 12;
            int cy0 = py + 68 + 36;
            int cw = pw - sideW - rightW - 28;
            String[] cards = {"Визуалы", "Интерфейс", "HUD", "Рендер", "Настройки"};
            Nav[] jump = {Nav.VISUALS, Nav.INTERFACE, Nav.HUD, Nav.RENDER, Nav.SETTINGS};
            for (int i = 0; i < cards.length; i++) {
                int cx = cx0 + (i % 3) * (cw / 3 + 4);
                int cy = cy0 + (i / 3) * 70;
                int cw2 = cw / 3 - 8;
                if (mx >= cx && mx <= cx + cw2 && my >= cy && my <= cy + 60) {
                    nav = jump[i];
                    clickUi();
                    return true;
                }
            }
            int bx = px + sideW + 12;
            int by = py + ph - 36;
            if (mx >= bx && mx <= bx + 120 && my >= by && my <= by + 18) {
                if (client != null) {
                    client.setScreen(new LayoutEditScreen(this, targetHUD, potionsRenderer, watermarkRenderer, inventoryHud));
                }
                return true;
            }
        }

        // toggles
        if (nav != Nav.HOME) {
            int cx = px + sideW + 12;
            int cy = py + 68 + 22 - scroll;
            int cw = pw - sideW - rightW - 28;
            String q = search.toLowerCase(Locale.ROOT);
            int idx = 0;
            for (Row r : rows) {
                if (r.nav != nav) { idx++; continue; }
                if (!q.isEmpty() && !r.title.toLowerCase(Locale.ROOT).contains(q)
                        && !r.desc.toLowerCase(Locale.ROOT).contains(q)) {
                    idx++;
                    continue;
                }
                int tw = 34, th = 18;
                int tx = cx + cw - 14 - tw;
                int ty = cy + 6;
                if (mx >= tx - 4 && mx <= tx + tw + 4 && my >= ty - 2 && my <= ty + th + 2) {
                    r.set.accept(!r.get.get());
                    ModConfig.save();
                    clickUi();
                    return true;
                }
                cy += 30;
                idx++;
            }
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int key = input.key();
        if (key == GLFW.GLFW_KEY_ESCAPE) {
            close();
            return true;
        }
        if (searchFocus) {
            if (key == GLFW.GLFW_KEY_BACKSPACE && !search.isEmpty()) {
                search = search.substring(0, search.length() - 1);
                return true;
            }
        }
        return super.keyPressed(input);
    }

    @Override
    public boolean charTyped(CharInput input) {
        if (searchFocus) {
            char c = input.codepoint() > 0 ? (char) input.codepoint() : 0;
            if (c >= 32 && search.length() < 32) {
                search += c;
                return true;
            }
        }
        return super.charTyped(input);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        scroll = (int) Math.max(0, scroll - v * 18);
        return true;
    }

    @Override
    public void close() {
        ModConfig.save();
        if (client != null) client.setScreen(parent);
    }

    private void clickUi() {
        if (!ModConfig.uiSounds || client == null) return;
        try {
            client.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK.value(), 1.1f, 0.2f));
        } catch (Throwable ignored) {}
    }

    private static final class Row {
        final Nav nav;
        final String title;
        final String desc;
        final Supplier<Boolean> get;
        final Consumer<Boolean> set;
        Row(Nav nav, String title, String desc, Supplier<Boolean> get, Consumer<Boolean> set) {
            this.nav = nav;
            this.title = title;
            this.desc = desc;
            this.get = get;
            this.set = set;
        }
    }
}
