Nik Visuals 3.9.1

- Diamond + Netherite 3D swords from BlackGreen HD pack (models + textures)
- Smaller menu (400x230), no right promo panel, less glow/circles
- Classic trajectory + golden apple textures kept
